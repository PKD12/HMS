from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.models import User,auth,Group
from .models import Appointment,Payment,Prescription
import random 
# Create your views here.
def home(request):
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def profile(request):
    group=request.user.groups.all()[0]   
    return render(request,'profile.html',{'group':group})

def login(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['pass']

        user=auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('home')

        else:
            messages.error(request,'Invalid Login Credentials, Please Try Again!')
            return redirect('home')
        return redirect('/')
    else:
        return render(request,'login.html')

def register(request):

    if request.method == 'POST':
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        username=request.POST['username']
        email=request.POST['email']
        password1=request.POST['pass']
        password2=request.POST['confpass']
        typed=request.POST['type']
        
        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.error(request,'User Name already exists, Please Try Again!')
                return redirect('home')
            else:
                user=User.objects.create_user(first_name=firstname, last_name=lastname, username=username, email=email, password=password1)
                user.save()
                if typed=="patient":
                    my_group = Group.objects.get(name="Patient") 
                elif typed=="doctor":
                    my_group = Group.objects.get(name="Doctor") 
                my_group.user_set.add(user)
                messages.success(request,'User Succesfully Registered, Please Sign In!')
                return redirect('home')
            
        else:
            messages.error(request,'Entered Passwords do not match, Please Try Again!')
            return redirect('home')
        return redirect('/')

    else:
        return render(request,'register.html')


def logout(request):
    auth.logout(request)
    return redirect('/')

def appointment(request):
    group = request.user.groups.all()[0]
    username=request.user.get_full_name()
    if request.method=="POST":
        if request.user.groups.filter(name='Patient').exists():
            docname=request.POST['doctorname']
            time=request.POST['time']
            date=request.POST['date']
            status=request.POST['status']
            y=Appointment.objects.create(doctorname=docname, patientname=username, date=date, time=time, status=random.choice(['Pending','Completed']))
            y.save()
            messages.success(request,'Appointment Submitted Successfully!')
            return redirect('appointment/')
    elif request.method=="GET":
        if request.user.groups.filter(name='Patient').exists():
            
            app=Appointment.objects.all()
            l=[]
            for i in app:
                if i.patientname==username:
                    l.append(i.id)
            
            p1=Appointment.objects.filter(pk__in=l)
            return render(request,'appointment.html',{'p1':p1})

        elif request.user.groups.filter(name='Doctor').exists():
            app=Appointment.objects.all()
            l=[]
            for i in app:
                if i.doctorname==username:
                    l.append(i.id)
            
            p1=Appointment.objects.filter(pk__in=l)
            return render(request,'appointment.html',{'p1':p1})
        else:
            print("Else")
            return render(request,'appointment.html',{'p1': []})

def app(request):
    return render(request,'app.html')

def apptwo(request):
    return render(request,'apptwo.html')

def description(request):
    return render(request,'description.html')

def payment(request):
    p1 = Payment.objects.all()
    return render(request,'payment.html',{'p1':p1})

def history(request):
    username=request.user.get_full_name()
    if request.user.groups.filter(name='Patient').exists():
        app=Prescription.objects.all()
        l=[]
        for i in app:
            if i.patientname==username:
                l.append(i.id)
        
        p1=Prescription.objects.filter(pk__in=l)
        return render(request,'history.html',{'p1':p1})
    elif request.user.groups.filter(name='Doctor').exists():
        if request.method=="GET":
            app=Prescription.objects.all()
            l=[]
            for i in app:
                if i.doctorname==username:
                    l.append(i.id)
            
            p1=Prescription.objects.filter(pk__in=l)
            return render(request,'history.html',{'p1':p1})
        elif request.method=="POST":
            prescription=request.POST['prescription']
            symptoms=request.POST['symptoms']
            date=request.POST['date']
            patientname=request.POST['patientname']
            y=Prescription.objects.create(doctorname=username, patientname=patientname, date=date, symptoms=symptoms, prescription=prescription)
            y.save()
            messages.success(request,'Prescription Submitted Successfully!')
            return redirect('history/')
        
def dashboard(request):
    if request.method=='GET':
        if request.user.groups.filter(name='Receptionist').exists():
            app=Appointment.objects.all()
            user = User.objects.all()
            pcount=0
            count=0
            for i in app:
                if i.status=='Pending':
                    pcount+=1
                count+=1
            rcount=count-pcount
            l=[]
            for i in user:
                if i.groups.filter(name='Patient').exists():
                    l.append(i.id)
            
            p1=User.objects.filter(pk__in=l)
            
            return render(request,'dashboard.html',{'p1':app,'p2':p1,'pc':pcount,'rc':rcount,'c':count})
        elif request.user.groups.filter(name='HR').exists():
            user = User.objects.all()
            doc=0
            pat=0
            for i in user:
                if i.groups.filter(name='Doctor').exists():
                    doc+=1
                elif i.groups.filter(name='Patient').exists():
                    pat+=1
            l=[]
            for i in user:
                if i.groups.filter(name='Doctor').exists():
                    l.append(i.id)
            
            p1=User.objects.filter(pk__in=l)
            return render(request,'dashboard.html',{'p2':p1,'pat':pat,'doc':doc})

    elif request.method=='POST':
        docname=request.POST['doctorname']
        patname=request.POST['patientname']
        time=request.POST['time']
        date=request.POST['date']
        status=request.POST['type']
        y=Appointment.objects.create(doctorname=docname, patientname=patname, date=date, time=time, status=status)
        y.save()
        messages.success(request,'Appointment Submitted Successfully!')
        return redirect('dashboard/')