from django.contrib.auth.models import User
from django.db import models

class Appointment(models.Model):
    doctorname=models.CharField(max_length=255)
    patientname=models.CharField(max_length=255)
    date = models.DateField(blank=True)
    time = models.TimeField(blank=True)
    status = models.CharField(max_length=255)

class Payment(models.Model):
    invoice=models.CharField(max_length=255)
    paid=models.IntegerField()
    date = models.DateField(blank=True)
    outstanding=models.IntegerField()

class Prescription(models.Model):
    date = models.DateField(blank=True)
    patientname=models.CharField(max_length=255)
    symptoms=models.CharField(max_length=255)
    prescription=models.CharField(max_length=255)
    doctorname=models.CharField(max_length=255)