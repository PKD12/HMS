from django.urls import path
from django.conf.urls import url
from . import views
urlpatterns=[
    path('',views.home,name='home'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    path('reg',views.register,name='register'),
    path('reg/register',views.register,name='register'),
    path('log',views.login,name='login'),
    path('log/login',views.login,name='login'),
    path('logout',views.logout,name='logout'),
    path('profile/',views.profile,name='profile'),
    url(r'appointment/$',views.appointment,name='appointment'),
    url(r'appointment/app/$',views.app,name='app'),
    path('payment/',views.payment,name='payment'),
    url(r'history/$',views.history,name='history'),
    url(r'history/description/$',views.description,name='description'),
    url(r'dashboard/$',views.dashboard,name='dashboard'),
    url(r'dashboard/apptwo/$',views.apptwo,name='apptwo'),
]