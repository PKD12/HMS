from django.contrib import admin

from .models import Appointment,Payment,Prescription

admin.site.register(Appointment)
admin.site.register(Payment)
admin.site.register(Prescription)